const form = document.getElementById('form');
const text = document.getElementById('text');
const amount = document.getElementById('amount');
const date = document.getElementById('date');
const category = document.getElementById('category');
const list = document.getElementById('list');
const balance = document.getElementById('balance');
const income = document.getElementById('income');
const expense = document.getElementById('expense');

let transactions = JSON.parse(localStorage.getItem('transactions')) || [];

form.addEventListener('submit', e => {
  e.preventDefault();
  const transaction = {
    id: Date.now(),
    text: text.value,
    amount: +amount.value,
    date: date.value,
    category: category.value
  };
  transactions.push(transaction);
  updateLocalStorage();
  renderTransactions();
  text.value = '';
  amount.value = '';
  date.value = '';
  category.value = 'general';
});

function renderTransactions() {
  list.innerHTML = '';
  let total = 0, incomeTotal = 0, expenseTotal = 0;

  transactions.forEach(tx => {
    const sign = tx.amount > 0 ? '+' : '-';
    const li = document.createElement('li');
    li.classList.add(tx.amount < 0 ? 'expense' : '');
    li.innerHTML = `
      ${tx.text} (${tx.category}) <br>
      Rs ${sign}${Math.abs(tx.amount)} | ${tx.date}
      <button onclick="deleteTransaction(${tx.id})">x</button>
    `;
    list.appendChild(li);

    total += tx.amount;
    tx.amount > 0 ? incomeTotal += tx.amount : expenseTotal += tx.amount;
  });

  balance.innerText = `Rs ${total}`;
  income.innerText = `Rs ${incomeTotal}`;
  expense.innerText = `Rs ${Math.abs(expenseTotal)}`;
}

function deleteTransaction(id) {
  transactions = transactions.filter(tx => tx.id !== id);
  updateLocalStorage();
  renderTransactions();
}

function exportCSV() {
  const headers = ['Text', 'Amount', 'Date', 'Category'];
  const rows = transactions.map(tx => [tx.text, tx.amount, tx.date, tx.category]);
  let csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].map(e => e.join(",")).join("\n");
  const link = document.createElement("a");
  link.setAttribute("href", encodeURI(csvContent));
  link.setAttribute("download", "finance_data.csv");
  document.body.appendChild(link);
  link.click();
}

function updateLocalStorage() {
  localStorage.setItem('transactions', JSON.stringify(transactions));
}

renderTransactions();