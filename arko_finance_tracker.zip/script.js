let entries = JSON.parse(localStorage.getItem("entries")) || [];

function renderEntries() {
  const list = document.getElementById("entries");
  list.innerHTML = "";
  entries.forEach((entry, i) => {
    const li = document.createElement("li");
    li.textContent = `${entry.date} - ${entry.category} - Rs.${entry.amount}`;
    list.appendChild(li);
  });
}

document.getElementById("entryForm").addEventListener("submit", e => {
  e.preventDefault();
  const date = document.getElementById("date").value;
  const category = document.getElementById("category").value;
  const amount = document.getElementById("amount").value;
  entries.push({ date, category, amount });
  localStorage.setItem("entries", JSON.stringify(entries));
  renderEntries();
});

document.getElementById("exportBtn").addEventListener("click", () => {
  const csv = "Date,Category,Amount\n" + entries.map(e => `${e.date},${e.category},${e.amount}`).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "finance_data.csv";
  a.click();
});

renderEntries();